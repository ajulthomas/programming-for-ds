
#Assignment
# module to handle clustering
#method available generate_K_cluster_centers, calculate_all_distances, find_shortest_distance, calculate_memberships, calculate_sum_2, calculate_cluster_centres

#function to calculate distance
def calculate_distance():
    distance = "" ##find distance
    return distance


#function to find cluster center
def calculate_cluster_center():
	cluster_center = None
	return cluster_center

#generate cluster centers with K
def generate_K_cluster_centres(num_of_coordinate,dimension):
    cluster_center_list = None
    return cluster_center_list


###other functions
###more functions here