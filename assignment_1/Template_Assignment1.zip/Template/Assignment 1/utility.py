###function to calculate distance
def calculate_distance(point1, point2):
    distance = 0
    ##write your code here.
    return distance



###function to find the cluster
def find_cluster(point, centroids):
    clusture = []
    return clusture
