#!/usr/bin/env python
# coding: utf-8

# # Week 11 Tutorial Pandas and Scikit-learn Packages
# 
# Total mark for assessment: 3%. Complete and submit all questions: 2%, and lab attendance: 1%. Submit after 23:59 (midnight): -0.5% and -0.5% for each day after. 
# 
# ## Objectives
# * To use Pandas for database and data manipulation
# * To use Scikit-learn for classification in machine learning
# ## Pandas Package
# * Create a new Python project and name it PandasScikitlearn.
# * You will work on this online CSV file https://raw.github.com/neurospin/pystatsml/master/datasets/salary_table.csv . Have a look at the data in this file on a web browser.
# 
# ## Example 1: Read data from that CSV file
# * Check if Pandas is available in Python Environments in your project. Install it if it is not.
# * Enter the following to the PandasDatabase.py file to use Pandas 

# In[8]:


import pandas as pd

#Example 1: Read data from an online CSV file.

url = 'https://raw.github.com/neurospin/pystatsml/master/datasets/salary_table.csv'
salary = pd.read_csv(url)
print(salary)


# ## Example 2: Change the order of columns in the salary table

# In[9]:


#Example 2: Change the order of columns in the salary table
cols = ['education', 'experience', 'management', 'salary']
salary2 = salary[cols] # or salary2 = salary.loc[:, cols]
print(salary2)


# ## Example 3: Filter the salary table

# In[10]:


#Example 3: Select rows for Master
rows = salary['education']=='Master'
master_salary = salary[rows] # or master_salary = salary.loc[rows, :]
print(master_salary)


# ## Example 4: Select rows and columns for Bachelor
# * You output the data for Bachelor only and do not print the education column. There are 3 options to output the same result. Add the following code example to do that.
# 
# * The three outputs have the same result:
# 
# ![](T10-Ex4.png)

# In[11]:


#Example 4: Select rows and columns for Bachelor
rows = salary['education']=='Bachelor'
cols = ['experience', 'management', 'salary']

print('1. Select rows then cols:')
salary_rows = salary[rows]
salary_rows_cols = salary_rows[cols]
print(salary_rows_cols)

print('2. Select rows and cols:')
salary_rows_cols = salary[rows][cols]
print(salary_rows_cols)

print('3. Use loc function:')
salary_loc = salary.loc[rows, cols]
print(salary_loc)


# ## Example 5: Sort the salary table
# * You sort the data in salary table by education then salary in descending order. Add the following code example to do that

# In[12]:


#Example 5: Sort the salary table
sorted_salary = salary.sort_values(by=['education', 'salary'], ascending=False)
print(sorted_salary)


# ## Example 6: Output to a CSV file
# * You output the sorted list to a CSV file then open that CSV file to read data in. Use the following code example.
# 
# * Run the project. The output would be the same as that in Example 5. 
# 
# * Below is part of the data in that CSV file:
# 
# ![](T10-Ex6.png)

# In[13]:


#Example 6: Output data to a CSV file
import tempfile, os.path

tmpdir = tempfile.gettempdir()
csv_filename = os.path.join(tmpdir, "sorted_salary.csv")
print(tmpdir)

sorted_salary.to_csv(csv_filename, index=False)
input_csv = pd.read_csv(csv_filename)
print(input_csv)


# ## Example 7: Output to an Excel file
# * You output the sorted list to an Excel file then open that Excel file to read data in. Use the following code example:
# 
# * Run the project. The output would be the same as that in Example 5.
# 
# * Below is part of the data in that CSV file:
# 
# ![](T10-Ex6.png)
# 

# In[14]:


#Example 7: Output data to a Excel file
import tempfile, os.path

tmpdir = tempfile.gettempdir()
excel_filename = os.path.join(tmpdir, "salary.xlsx")
print(tmpdir)

sorted_salary.to_excel(excel_filename, sheet_name='Sorted salary', index=False)
input_excel = pd.read_excel(excel_filename)
print(input_excel)


# ### Question 1: Output data in the sorted salary table to an Excel file in 3 sheets for Ph.D, Master and Bachelor.
# 
# * Write a program that outputs data from **sorted salary** in **Example 5** to an Excel file named **salary3.xlsx**. This file has 3 sheets and the sheet names are **Ph.D, Master and Bachelor**. The data in the sheet name Ph.D are for PhD only and presented in 3 columns **experience, management and salary.** The same requirement for the data in two sheets for Master and Bachelor. 
# 
# * You also need to open this Excel file and read data from the 3 sheets in and output data to screen as seen in the screenshots below.

# ![](Q1.png)

# In[15]:


#Question 1 Method1:

import pandas as pd
import tempfile, os.path
tmpdir = tempfile.gettempdir()
excel_filename = os.path.join(tmpdir, "salary3.xlsx")

url = 'https://raw.github.com/neurospin/pystatsml/master/datasets/salary_table.csv'
salary = pd.read_csv(url)
sorted_salary = salary.sort_values(by=['education', 'salary'], ascending=False)

#excel_filename = 'salary3.xlsx'

writer = pd.ExcelWriter(excel_filename, engine = 'openpyxl')

for degree in sorted_salary.education.unique():
    rows = sorted_salary['education']==degree
    cols = ['experience', 'management', 'salary']
    salary_rows_cols = sorted_salary[rows][cols]
    salary_rows_cols.to_excel(writer, sheet_name=degree, index=False)
    writer.save()
    writer.close()

book = pd.ExcelFile(excel_filename) #read the workbook

for sheet_name in book.sheet_names: #Loop through the sheets in workbook
    print(f'Salary for {sheet_name}:')
    print(book.parse(sheet_name))  #Parse the sheet and print out as Q1 required


# In[16]:


#Question 1 Method2:

import pandas as pd
import tempfile, os.path
tmpdir = tempfile.gettempdir()
excel_filename = os.path.join(tmpdir, "salary3.xlsx")

url = 'https://raw.github.com/neurospin/pystatsml/master/datasets/salary_table.csv'
salary = pd.read_csv(url)
sorted_salary = salary.sort_values(by=['education', 'salary'], ascending=False)

with pd.ExcelWriter(excel_filename) as excel_writer:
    for degree in sorted_salary.education.unique():
        rows = sorted_salary['education']==degree
        cols = ['experience', 'management', 'salary']
        salary_rows_cols = sorted_salary[rows][cols]
        salary_rows_cols.to_excel(excel_writer, sheet_name=degree, index=False)

book = pd.ExcelFile(excel_filename) #read the workbook

for sheet_name in book.sheet_names: #Loop through the sheets in workbook
    print(f'Salary for {sheet_name}:')
    print(book.parse(sheet_name))  #Parse the sheet and print out as Q1 required


# ## Question 2: Output data in the sorted salary table to an SQLite database file.
# * Write a program that reads data from the sorted_salary.csv file in Example 6 and outputs these data to an SQLite database file named salary.db. You also write code to open this database file and reads data in and output the data on screen.

# In[17]:


#Question 2:
import pandas as pd
import tempfile, os.path
import sqlite3

#Directory and filenames
db_tmpdir = tempfile.gettempdir()
db_filename = os.path.join(db_tmpdir, "salary.db")

#Connect
conn = sqlite3.connect(db_filename)

#Prepare data for write
url = 'https://raw.github.com/neurospin/pystatsml/master/datasets/salary_table.csv'
salary = pd.read_csv(url)
sorted_salary = salary.sort_values(by=['education', 'salary'], ascending=False)
csv_tmpdir = tempfile.gettempdir()
csv_filename = os.path.join(csv_tmpdir, "sorted_salary.csv")
sorted_salary.to_csv(csv_filename, index=False)

#write data to SQL table sorted3
results = pd.read_csv(csv_filename)
results.to_sql("sorted3", conn, if_exists="replace")


# In[18]:


#read data from SQL lite
degrees = pd.read_sql_query("select distinct education from sorted3;", conn)
print(degrees.iteritems)
#print(type(degrees))
#print(degrees.iterrows)

for degree in sorted_salary.education.unique():
    results_sql = pd.read_sql_query(f'select * from sorted3 where education like "{degree}";', conn)
    print(f'Salary for {degree}:')
    print(results_sql)


# In[20]:



results_sql = pd.read_sql_query("select * from sorted3;", conn)
print(results_sql)


# ## Scikit-learn package
# * Scikit-learn provides simple and efficient tools for predictive data analysis
# * Scikit-learn provides built-in estimators or classifiers (machine learning techniques and models) that can be fitted to some data using its fit method.
# * Once the estimator is fitted, you can use it for predicting target values of unknown data samples without re-training the estimator.
# ## Load Iris dataset
# * Add the following line to have modules in scikit-learn package 

# In[21]:


from sklearn import datasets, neighbors, metrics, svm
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt


# •	Add the following line to get iris dataset

# In[22]:


#Load data set
dataset = datasets.load_iris()
print(dataset)


# •	Run your program to see what is included in the iris dataset. You will only need to get data (data samples in an np-array), target (class index of data samples in a list), and target_names (class names or class labels in a list). Add the following code and run to output them.

# In[23]:


X = dataset.data
print('Array of data samples:')
print(X)
print()

n_samples, n_features = X.shape
print('Number of data samples: ', n_samples)
print('Dimensionality (Number of features): ', n_features)
print()

y = dataset.target
print('True class index of data samples:')
print(y)
print()

class_names = dataset.target_names
print('Array of class names:', class_names)
print('Number of classes:', len(class_names))
print()


# •	You will split the dataset into training set and testing set using train_test_split function. Add the following code and run

# In[24]:


#Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)
print(X_train)
print()
print(X_test)
print()
print(y_train)
print()
print(y_test)
print()


# `test_size=0.2` means 25% data samples are in testing set (X_test) and 75% data samples are in training set (`X_train`). The same is applied to `y_train` and `y_test` lists comparing with the y list. 
# 
# `random_state=0` is to have the same data in `X_train, X_test, y_train, y_test` every time you run your program. To have different data for each run change to large number, for example `random_state=42`. 

# ### Load classifier (machine learning technique and model) for training and testing  
# •	Add a classifier (machine learning technique and model) to your program

# In[25]:


#Load classifier containing classification technique and model
classifier = neighbors.KNeighborsClassifier(n_neighbors=3)


# If `n_neighbors=1` this `KNeighborsClassifier` will be the nearest neighbour classifier you implemented in Assignment 1.
# 
# •	Now you use y_train to train the classifier and use y_test to test that classifier. Add the following code to do that
# 

# In[26]:


#Training
classifier.fit(X_train, y_train)

#Testing
y_pred = classifier.predict(X_test)
print(y_pred)


# ### Output confusion matrix  
# •	The confusion_matrix function is used to evaluate classification accuracy of a classifier. Add the following code and run to plot confusion matrix. 

# In[27]:


#Plot confusion matrix
metrics.plot_confusion_matrix(classifier, X_test, y_test, display_labels=class_names) 
plt.show()  


# ![](T10-ClassiferOut.png) 
# 
# •	Numbers in the plot are numbers of samples classified (predicted) for each class. For example, number 1 in the plot shows there is 1 sample of versicolor that is incorrectly classified as virgina.
# 
# ### Change parameter and classifier
# 
# •	Change parameter: replace n_neighbors=3 with n_neighbors=1 then run your program again. Compare numbers in the confusion matrix with the numbers when you run your program with n_neighbors=3.
# 
# •	Change classifier: replace the line 
# 
# `classifier = neighbors.KNeighborsClassifier(n_neighbors=1)`
# 
# with
# 
# `classifier = svm.SVC(gamma=0.5)`
# 
# to use Support Vector Machine classifier then run your program.
# 
# •	Change parameter: replace gamma=0.5 with gamma=0.1 then run your program again. Compare numbers in the confusion matrix with the numbers when you run your program with gamma=0.5.
# 
# ### Classification accuracy
# •	Change dataset back to Iris
# 
# `dataset = datasets.load_iris()`
# 
# and change classifier back to K-Neighbour classifier
# 
# `classifier = neighbors.KNeighborsClassifier(n_neighbors=3)`
# 
# •	Use print(y_pred) and print(y_test) to print out values. Below are their values (the first line is from y_pred)
# 
# `[2 1 0 2 0 2 0 1 1 1 2 1 1 1 1 0 1 1 0 0 2 1 0 0 2 0 0 1 1 0 2 1 0 2 2 1 0 2]
# 
# [2 1 0 2 0 2 0 1 1 1 2 1 1 1 1 0 1 1 0 0 2 1 0 0 2 0 0 1 1 0 2 1 0 2 2 1 0 1]`
# 
# •	The y_test list contains indices of true classes (0 for Setosa, 1 for Versicolour and 2 for Virginica). The y_pred list contains indices of predicted classes. Compare these values you will see that only the last number (2) in y_pred is different from the last index in y_test (1). This means that the last data sample in X_test having true class 1 (Versicolour) is correctly classified as 2 (Virginica). Using the following
# 
# `accuracy (in %) = 100% * number of correctly classified samples in y_predict / number of all samples in y_predict`
# 
# you will have the `accuracy = 100% *  37 / 38 = 97.37%`

# ## Question 3:  
# * Write a function to calculate classification accuracy using true class index list in y_test and predicted class index list in y_pred. The function is as follows 

# In[28]:


from sklearn import datasets, neighbors, metrics, svm
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

dataset = datasets.load_iris()
classifier = neighbors.KNeighborsClassifier(n_neighbors=3)

X = dataset.data
y = dataset.target
#Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

#Training
classifier.fit(X_train, y_train)

#Testing
y_pred = classifier.predict(X_test)
print(y_pred)


# In[29]:


#############################################
def get_accuracy(true_list, predicted_list):
    mismatch = 0
    for index, (test, predict) in enumerate(zip(true_list, predicted_list)):
        if test != predict:
            mismatch+=1
            #print(index, test)
    accuracy =( 1 - (mismatch / len(true_list))) * 100

    return accuracy #accuracy in %
#############################################


# * After you finish implementing the function, add the following to call the function to get the accuracy
# 

# In[30]:


accuracy = get_accuracy(y_test, y_pred)
print('Accuracy: ' + str(accuracy) + '%')


# * You will get the output Accuracy: 97.36842105263158%. Change parameter and classifier to get accuracy of each case.

# In[31]:


from sklearn import datasets, neighbors, metrics, svm
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

dataset = datasets.load_iris()
classifier = neighbors.KNeighborsClassifier(n_neighbors=1)

X = dataset.data
y = dataset.target
#Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

#Training
classifier.fit(X_train, y_train)

#Testing
y_pred = classifier.predict(X_test)
print(y_pred)


# In[32]:


accuracy = get_accuracy(y_test, y_pred)
print('Accuracy: ' + str(accuracy) + '%')


# In[33]:


from sklearn import datasets, neighbors, metrics, svm
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

dataset = datasets.load_iris()
classifier = svm.SVC(gamma=0.5)

X = dataset.data
y = dataset.target
#Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

#Training
classifier.fit(X_train, y_train)

#Testing
y_pred = classifier.predict(X_test)
print(y_pred)


# In[34]:


accuracy = get_accuracy(y_test, y_pred)
print('Accuracy: ' + str(accuracy) + '%')

